/**
 * Clase que representa el webmaster de una web.
 *
 * @author Natalia Partera
 * @version 1.0
 */


public class WebMaster extends UsuarioWeb implements {

}
