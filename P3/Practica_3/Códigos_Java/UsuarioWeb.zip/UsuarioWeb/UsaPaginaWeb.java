/**
 * Programa que simula el uso de una página web.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class UsaPaginaWeb
{
  public static void main (String args[]) 
  {

  }
}
