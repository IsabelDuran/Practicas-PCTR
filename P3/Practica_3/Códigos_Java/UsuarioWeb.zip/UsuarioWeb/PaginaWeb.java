/**
 * Clase que representa una página web.
 *
 * @author Natalia Partera
 * @version 1.0
 */


public class PaginaWeb {
  String url;
  String bienvenida;
  WebMaster webmaster;
  LinkedList usuariosConectados;

  void DarBienvenida() {}
  
}
