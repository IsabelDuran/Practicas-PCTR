  public class Clase
  {
    private int atrib;
    
    //Constructor
    public Clase(int at) {
      atrib = at;
    }

    //Método observador
    public int Atributo() {
      return atrib;
    }

    //Método modificador
    public void Atributo(int at) {
      atrib = at;
    }
  }
