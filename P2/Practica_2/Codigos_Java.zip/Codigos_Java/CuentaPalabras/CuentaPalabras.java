/**
 * Programa en Java que recibe un archivo y cuenta las palabras que contiene.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class CuentaPalabras {

  static int NumPalabras(FileInputStream entrada) {
    int cont = 0, p;
    char c;

    try {
      while ((p = entrada.read()) >= 0) {
        c = Character.toLowerCase((char) p);
        if (c == ' ')
          ++cont;
      }
      entrada.close();
    } catch (IOException e) {
      System.err.println("Problemas de E/S");
      System.err.println(e.getMessage());
      System.exit(1);
    } 
    return cont;
  }

  public static void main (String args[]) {
    int palabras;

    if (args.length != 1) {
      System.err.println("Debe incluir el nombre del fichero de lectura en el argumento.");
      System.exit(1);
    }
    try {
      FileInputStream origen = new FileInputStream(args[0]);
      palabras = NumPalabras(origen);
      System.out.println("El archivo consta de " + palabras + " palabras.");
    } catch (FileNotFoundException e) {
      System.err.println("Fichero no encontrado...");
      System.err.println(e.getMessage());
      System.exit(1);
    }
  }
}

