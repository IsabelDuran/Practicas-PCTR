/**
 * Clase que realiza conversiones de dólares a euros.
 *
 * @author Natalia Partera
 * @version 2.0
 */

public class Conversor
{
  //Atributo privado: factor de conversión
  private double factorConver;

  //Constructor
  public Conversor(double factor) {
    factorConver = factor;
  }

  //Método observador
  public double FactorConversion() {
    return factorConver;
  }

  //Método modificador
  public void FactorConversion(double nuevoFact) {
    factorConver = nuevoFact;
  }

  //Método observador
  public double Convertir(double cantidad) {
    return cantidad*factorConver;
  }
}
