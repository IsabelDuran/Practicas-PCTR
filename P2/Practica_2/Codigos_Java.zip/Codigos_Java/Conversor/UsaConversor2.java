/**
 * Programa que utiliza la clase Conversor.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class UsaConversor2
{
  public static void main (String[] args)
  {
    if(args.length != 2) {
      System.err.println("Sintaxis incorrecta.");
      System.err.println("Sintaxis: java UsaConversor2 factor_de_conversion cantidad_a_convertir");
      System.exit(-1);
    }

    double conver = Double.valueOf(args[0]).doubleValue();
    double cant = Double.valueOf(args[1]).doubleValue();
    Conversor eurosDolares;

    eurosDolares = new Conversor(conver);

    System.out.println("Factor de conversión: 1 € = " + eurosDolares.FactorConversion() + " $");
    System.out.println(cant + " € son " + eurosDolares.Convertir(cant) + " $");
  }
}
