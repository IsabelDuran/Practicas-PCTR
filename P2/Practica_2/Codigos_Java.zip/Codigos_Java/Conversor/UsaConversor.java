/**
 * Programa que utiliza la clase Conversor.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class UsaConversor
{
  public static void main (String[] args)
  {
    Scanner teclado = new Scanner(System.in);
    Conversor eurosDolares, dolaresEuros;

    eurosDolares = new Conversor(1.31086);
    dolaresEuros = new Conversor(0.762860);

    System.out.println("Recuerde que para introducir números decimales debe usar ','");
    System.out.print("Introduzca la cantidad que quiere convertir de euros a dólares: ");
    double euros = teclado.nextDouble();
    System.out.println("Factor de conversión: 1 € = " + eurosDolares.FactorConversion() + " $");
    System.out.println(euros + " € son " + eurosDolares.Convertir(euros) + " $");
    System.out.println("Actualice el factor de conversión.");
    System.out.print("Ahora 1 € vale en dólares: ");
    double nuevoFact = teclado.nextDouble();
    eurosDolares.FactorConversion(nuevoFact);
    System.out.println("Factor de conversión actualizado.");
    System.out.println("Ahora 1 € = " + eurosDolares.FactorConversion() + " $");

    System.out.print("Introduzca la cantidad que quiere convertir de dólares a euros: ");
    double dolares = teclado.nextDouble();
    System.out.println("Factor de conversión: 1 € = " + dolaresEuros.FactorConversion() + " $");
    System.out.println(dolares + " $ son " + dolaresEuros.Convertir(dolares) + " €");
    System.out.println("Actualice el factor de conversión.");
    System.out.print("Ahora 1 $ vale en euros: ");
    nuevoFact = teclado.nextDouble();
    dolaresEuros.FactorConversion(nuevoFact);
    System.out.println("Factor de conversión actualizado.");
    System.out.println("Ahora 1 $ = " + dolaresEuros.FactorConversion() + " €");
  }
}
