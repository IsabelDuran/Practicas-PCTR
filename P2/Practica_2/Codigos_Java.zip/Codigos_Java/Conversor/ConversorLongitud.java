/**
 * Programa que utiliza la clase Conversor.
 *
 * @author Natalia Partera
 * @version 1.0
 */

public class ConversorLongitud
{
  public static void main (String[] args)
  {
    Conversor mInch, celsiusKelvin;

    mInch = new Conversor(39.3700787);
    celsiusKelvin = new Conversor();

    System.out.print("Conversor de metros a pulgadas");
    System.out.println("Factor de conversión: 1 metro = " + mInch.FactorConversion() + " pulgadas");
    double metros = 0.25;
    System.out.println(metros + " metros son " + mInch.Convertir(metros) + " pulgadas");
    mInch.FactorConversion(mInch.FactorConversion()/100);
    double cm = 25;
    System.out.println(cm + " cm son " + mInch.Convertir(cm) + " pulgadas");
  }
}
