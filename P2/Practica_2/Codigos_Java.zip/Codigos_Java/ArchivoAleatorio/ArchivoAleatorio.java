/**
 * Programa que ilustra cómo trabajar con archivos de acceso aleatorio.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class ArchivoAleatorio {

  public static void main(String arg[]) {
    char c;
    boolean finArchivo = false;
    RandomAccessFile archivo = null;

    try {
      archivo = new RandomAccessFile("prueba.txt", "rw");
      System.out.println("El archivo ha sido abierto en modo de lectura y escritura.");
      System.out.println("El tamaño es: " + archivo.length());
      do {
        try {
          c = (char) archivo.readByte();
          archivo.seek(archivo.getFilePointer() - 1);
          archivo.writeByte(Character.toUpperCase(c));
        } catch (EOFException e) {
          finArchivo = true;
          archivo.close();
          System.out.println("El contenido del archivo ahora está en mayúsculas.");
        }
      } while (!finArchivo);
    } catch (FileNotFoundException e) {
      System.out.println("No se encontró el archivo.");
    } catch (IOException e) {
      System.out.println("Problemas con el archivo.");
    }
  }
}
