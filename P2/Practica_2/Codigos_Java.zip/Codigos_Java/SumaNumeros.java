/**
 * Programa en Java que suma dos números obtenidos desde la entrada estándar.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;


public class SumaNumeros
{
  public static void main (String[] args)
  {
    double x, y;

    System.out.println("Suma de dos números");
    try {
      InputStream in = System.in;
      InputStreamReader isr = new InputStreamReader(in);
      BufferedReader br = new BufferedReader (isr);

      System.out.print("Primer sumando: ");
      String dato = br.readLine();
      if (!dato.isEmpty())
        x = Double.parseDouble(dato);
      else
        x = 0.0;

      System.out.print("Segundo sumando: ");
      dato = br.readLine();
      if (!dato.isEmpty())
        y = Double.parseDouble(dato);
      else
        y = 0.0;

      System.out.println(x + " + " + y + " = " + (x+y));

    } catch(IOException exc) {
      System.err.println("¡Ups! Ha tenido lugar un error de E/S");
      exc.printStackTrace();
      System.exit(-1);
    }
    
  }
}
