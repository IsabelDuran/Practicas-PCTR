/**
 * Programa en Java que dado un array de cadenas, calcula un array con las longitudes
 * de dichas cadenas.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class LongCadenas {
  public int[] Longitudes(String[] cadenas) {
    if(cadenas == null) {
      System.err.println("Array de cadenas vacío.");
      System.exit(-1);
    }

    int[] longit = new int[cadenas.length];
    int tam = 0;
    for(int i = 0; i < cadenas.length; ++i) {
      if(cadenas[i] != null)
        longit[i] = cadenas[i].length();
      else
        longit[i] = 0;
    }
    return longit;
  }

  public static void main (String[] args) {
    String[] cadenas = new String[5];
    cadenas[0] = new String("Amarillo");
    cadenas[1] = new String("Verde");
    cadenas[2] = new String("Azul");
    cadenas[3] = new String("Rojo");
    cadenas[4] = new String("Púrpura");

    LongCadenas lc = new LongCadenas();
    int[] longitudes = lc.Longitudes(cadenas);

    System.out.println("Longitudes de las cadenas: ");
    for(int i = 0; i < cadenas.length; ++i) {
      System.out.println(longitudes[i]);
    }
  }
}
