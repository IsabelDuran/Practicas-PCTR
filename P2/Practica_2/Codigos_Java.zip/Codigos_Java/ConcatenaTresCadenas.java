/**
 * Programa que recibe 3 cadenas como argumentos y las concatena.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class ConcatenaTresCadenas
{
  private String cad1, cad2, cad3, cadFinal;

  public ConcatenaTresCadenas() {
    cad1 = new String();
    cad2 = new String();
    cad3 = new String();
    cadFinal = new String();
  }

  public void Cadena1(String aux) {
    cad1 = aux;
  }

  public void Cadena2(String aux) {
    cad2 = aux;
  }

  public void Cadena3(String aux) {
    cad3 = aux;
  }

  public void CadenaFinal(String aux) {
    cadFinal = aux;
  }

  public String Cadena1() {
    return cad1;
  }

  public String Cadena2() {
    return cad2;
  }

  public String Cadena3() {
    return cad3;
  }

  public String CadenaFinal() {
    return cadFinal;
  }

  public static void main (String[] args)
  {
    ConcatenaTresCadenas conc = new ConcatenaTresCadenas();

    if(args.length != 3) {
      System.err.println("Sintaxis incorrecta.");
      System.err.println("Sintaxis: java ConcatenaTresCadenas cadena1 cadena2 cadena3");
      System.exit(-1);
    }

    conc.Cadena1(args[0]);
    conc.Cadena2(args[1]);
    conc.Cadena3(args[2]);

    conc.CadenaFinal(conc.Cadena1() + conc.Cadena2() + conc.Cadena3());

    System.out.println("Las cadenas " + conc.Cadena1() + ", " + conc.Cadena2() + " y " + conc.Cadena3() + " forman la cadena:");
    System.out.println(conc.CadenaFinal());
  }
}
