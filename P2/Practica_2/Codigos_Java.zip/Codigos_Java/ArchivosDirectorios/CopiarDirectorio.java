/**
 * Programa que recibe dos rutas (origen y destino) y 
 * copia el contenido del direcotrio origen en el directorio destino.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class CopiarDirectorio {


  public void copiarDirectorio (String rutaOrigen, String rutaDestino) {
    File origen = new File (rutaOrigen);
    File destino = new File (rutaDestino);
    if(!origen.isDirectory()) {
      System.err.println("No se pudo realizar la copia. El directorio origen no existe.");
      System.exit(1);
    }
    if(destino.isDirectory()) {
      System.err.println("No se pudo realizar la copia. El directorio destino ya existe.");
      System.exit(1);
    }

    String[] listaOrigen = origen.list();
    destino.mkdirs();
    for (int i = 0; i < listaOrigen.length; ++i) {
      File f = new File(origen.getAbsolutePath() + "/" + listaOrigen[i]);
      if(f.isFile()) {
        copiarArchivo(f.getAbsolutePath(), destino.getAbsolutePath(), true);
      }
      else {
        File d = new File(destino.getAbsolutePath() + "/" + f.getName());
        copiarDirectorio(f.getAbsolutePath(), d.getAbsolutePath());
      }
    }
  }

  public static void main (String args[]) {
    if(args.length != 2) {
      System.err.println("Error de sintaxis: $java CopiarDirectorio directorio_origen directorio_destino");
      System.exit(1);
    }
    copiarDirectorio(args[0], args[1]);
  }

}
