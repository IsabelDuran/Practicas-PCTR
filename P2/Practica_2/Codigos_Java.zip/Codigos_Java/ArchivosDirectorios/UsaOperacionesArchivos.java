/**
 * Programa que recibe dos rutas (origen y destino) y realiza copias entre ellas.
 *
 * @author Natalia Partera
 * @version 1.0
 */


public class UsaOperacionesArchivos {
  public static void main (String args[]) {
    if(args.length != 2) {
      System.err.println("Error de sintaxis: $java UsaOperacionesArchivos ruta_origen ruta_destino");
      System.exit(1);
    }
    OperacionesArchivos operarch = new OperacionesArchivos();
//    operarch.copiarArchivo(args[0], args[1]);
//    System.out.println("Archivo copiado con éxito.");
//    operarch.moverArchivo(args[0], args[1]);
//    System.out.println("Archivo movido con éxito.");
    operarch.copiarDirectorio(args[0], args[1]);
    System.out.println("Directorio movido con éxito.");
  }
}
