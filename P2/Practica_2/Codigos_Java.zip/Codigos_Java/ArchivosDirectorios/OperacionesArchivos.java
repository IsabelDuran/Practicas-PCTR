/**
 * Clase que inmplementa operaciones de copia sobre archivos y directorios.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class OperacionesArchivos {
  public OperacionesArchivos() {}

  public void copiarArchivo (String rutaOrigen, String rutaCopia) {
    if(rutaOrigen == null || rutaCopia == null) {
      System.err.println ("Argumentos no válidos.");
      System.exit(1);
    }
    File origen = new File(rutaOrigen);
    File copia = new File(rutaCopia);
    FileInputStream ent;
    FileOutputStream sal;
    if(copia.isDirectory()) {
      copia = new File(copia.getAbsolutePath() + "/" + origen.getName());
    }
    try {
      //System.out.println("Origen: " + origen.getAbsolutePath());
      ent = new FileInputStream(origen.getAbsolutePath());
      //System.out.println("Destino: " + copia.getAbsolutePath());
      sal = new FileOutputStream(copia.getAbsolutePath());
      int leido;
      while((leido = ent.read()) != -1) {
        sal.write(leido);
      }
      sal.close();
      ent.close();
    } catch (FileNotFoundException e) {
      System.err.println("Error al copiar: No se pudo abrir algún archivo."); 
      System.exit(1);
    } catch (IOException e) {
      System.err.println("Error al copiar: Error de lectura/escritura.");
    }
  }

  public void moverArchivo (String rutaOrigen, String rutaDestino) {
    if(rutaOrigen == null || rutaDestino == null) {
      System.err.println("Argumentos no válidos.");
      System.exit(1);
    }
    File origen = new File(rutaOrigen);
    File destino = new File(rutaDestino);
    try {
      copiarArchivo(origen.getAbsolutePath(), destino.getAbsolutePath());
      origen.delete();
    } catch (Exception e) {
      System.err.println("Error al mover.");
      System.exit(1);
    }
  }

  public void copiarDirectorio (String rutaOrigen, String rutaDestino) {
    if(rutaOrigen == null || rutaDestino == null) {
      System.err.println("Argumentos no válidos.");
      System.exit(1);
    }
    File origen = new File(rutaOrigen);
    File destino = new File(rutaDestino);
    if(!origen.isDirectory()) {
      System.err.println("No se pudo realizar la copia. El directorio origen no existe.");
      System.exit(1);
    }
    if(destino.isDirectory()) {
      System.err.println("No se pudo realizar la copia. El directorio destino ya existe.");
      System.exit(1);
    }

    String[] listaOrigen = origen.list();
    destino.mkdirs();
    for(int i = 0; i < listaOrigen.length; ++i) {
      File f = new File(origen.getAbsolutePath() + "/" + listaOrigen[i]);
      if(f.isFile()) {
        copiarArchivo(f.getAbsolutePath(), destino.getAbsolutePath());
      }
      else {
        File d = new File(destino.getAbsolutePath() + "/" + f.getName());
        copiarDirectorio(f.getAbsolutePath(), d.getAbsolutePath());
      }
    }
  }
}
