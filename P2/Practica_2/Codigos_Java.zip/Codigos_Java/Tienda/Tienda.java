/**
 * Programa que relaciona las referencias de los artículos con sus precios,
 * guardándolos en un fichero dado.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;
import java.util.*;

public class Tienda {
  public void ArticulosPrecios(int[] referencias, double[] precios, String nombreArchivo) {
    if(referencias.length != precios.length) {
      System.out.println("¡Cuidado! No hay el mismo número de referencias y precios.");
    }
    try {
      RandomAccessFile archivo = new RandomAccessFile(nombreArchivo, "rw");
      for(int i = 0; i < referencias.length && i < precios.length; ++i) {
        archivo.writeInt(referencias[i]);
        archivo.writeDouble(precios[i]);
      }
      archivo.close();
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    }
  }

  public void VerInventario(String nombreArchivo) {
    try {
      boolean finArchivo = false;
      int referencia;
      double precio;
      RandomAccessFile archivo = new RandomAccessFile(nombreArchivo, "r");
      do {
        try {
          referencia = archivo.readInt();
          precio = archivo.readDouble();
          System.out.println("El artículo con referencia " + referencia + " vale " + precio + " euros.");
        } catch(EOFException e) {
          finArchivo = true;
          archivo.close();
        }
      } while(!finArchivo);
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    }
  }

  public static void main(String[] args) {
    Tienda t = new Tienda();
    String archivo = "inventario.txt";
    int[] referencias = {123324, 561298, 112908, 127786, 432285};
    double[] precios = {14.95, 9.95, 24.95, 6.95, 45.95};
    t.ArticulosPrecios(referencias, precios, archivo);
    t.VerInventario(archivo);
  }
}
