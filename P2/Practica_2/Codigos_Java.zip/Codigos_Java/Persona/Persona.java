/**
 * Clase que guarda información sobre los datos de una persona.
 *
 * @author Natalia Partera
 * @version 2.0
 */

import java.io.*;

public class Persona implements Serializable {
  private String nombre, apellidos, email, ciudad, nacionalidad, profesion;
  private int edad, tlfn;

  public Persona() {}

  public Persona(String nomb, String ape, int ed, int tel, String mail, String ciud, String nacio, String prof) {
    nombre = nomb;
    apellidos = ape;
    edad = ed;
    tlfn = tel;
    email = mail;
    ciudad = ciud;
    nacionalidad = nacio;
    profesion = prof;
  }

  //Métodos observadores
  public String Nombre() {
    return nombre;
  }
  public String Apellidos() {
    return apellidos;
  }
  public int Edad() {
    return edad;
  }
  public int Telefono() {
    return tlfn;
  }
  public String Email() {
    return email;
  }
  public String Ciudad() {
    return ciudad;
  }
  public String Nacionalidad() {
    return nacionalidad;
  }
  public String Profesion() {
    return profesion;
  }
  //Métodos modificadores
  public void Nombre(String nomb) {
    nombre = nomb;
  }
  public void Apellidos(String ape) {
    apellidos = ape;
  }
  public void Edad(int ed) {
    edad = ed;
  }
  public void Telefono(int tel) {
    tlfn = tel;
  }
  public void Email(String mail) {
    email = mail;
  }
  public void Ciudad(String ciud) {
    ciudad = ciud;
  }
  public void Nacionalidad(String nacio) {
    nacionalidad = nacio;
  }
  public void Profesion(String prof) {
    profesion = prof;
  }
}
