/**
 * Programa que maneja información sobre los datos de una persona.
 *
 * @author Natalia Partera
 * @version 1.0
 */


public class UsaPersona {
  public static void main(String arg[]) {
    Persona p1 = new Persona("Marta", "Sánchez Sánchez", 16, 663777888, "marta@gmail.es", "Lugo", "española", "estudiante");

    System.out.println(p1.Nombre() + " " + p1.Apellidos() + " tiene " + p1.Edad() + " años.");
    System.out.println("Vive en " + p1.Ciudad() + " y tiene nacionalidad " + p1.Nacionalidad() + ".");
    System.out.println("Es " + p1.Profesion() + ". Puede llamarle al " + p1.Telefono() + " o mandarle un email a " + p1.Email());

    p1.Edad(32);
    p1.Telefono(632111222);
    p1.Ciudad("Nueva York");
    p1.Nacionalidad(p1.Nacionalidad() + " y estadounidense");
    p1.Profesion("economista");

    System.out.println("Algunos años después...");
    System.out.println(p1.Nombre() + " " + p1.Apellidos() + " tiene " + p1.Edad() + " años.");
    System.out.println("Vive en " + p1.Ciudad() + " y tiene nacionalidad " + p1.Nacionalidad() + ".");
    System.out.println("Es " + p1.Profesion() + ". Puede llamarle al " + p1.Telefono() + " o mandarle un email a " + p1.Email());
  }
}

