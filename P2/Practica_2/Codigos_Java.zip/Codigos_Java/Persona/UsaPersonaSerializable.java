/**
 * Programa que maneja información sobre los datos de personas.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;
import java.util.*;

public class UsaPersonaSerializable {
  public Persona[] inicializarListaPersonas() {
    Persona[] lista = new Persona[10];
    lista[0] =  new Persona("Marta", "Sánchez Sánchez", 16, 663777888, "marta@gmail.es", "Lugo", "española", "estudiante");
    lista[1] = new Persona("Mario", "Pérez López", 22, 699722011, "mariopl@gmail.es", "Málaga", "español", "fontanero");
    lista[2] = new Persona("Carmen", "Gómez García", 26, 611222333, "carmengg@gmail.es", "Badajoz", "española", "abogada");
    lista[3] = new Persona("Marco", "Polo Sur", 33, 633455644, "exploradores.sin.fronteras@gmail.es", "Venecia", "italiano", "explorador");
    lista[4] = new Persona("Inga", "Schmidt", 14, 677887778, "ingaschmidt@gmail.de", "Hamburgo", "alemana", "estudiante");
    lista[5] = new Persona("Juan", "Ruíz Méndez", 40, 699876543, "juanito@gmail.es", "Barcelona", "español", "profesor");
    lista[6] = new Persona("Ana", "Paez Gómez", 45, 623465432, "anita@gmail.es", "Bogotá", "colombiana", "arquitecta");
    lista[7] = new Persona("Sergio", "Rey Núñez", 58, 678123456, "el_rey_sergio@msn.es", "Palencia", "español", "albañil");
    lista[8] = new Persona("Aurelia", "Santos Inocente", 67, 612345678, "yaya_aurelia@gmail.es", "Guadalajara", "española", "jubilada");
    lista[9] = new Persona("John", "Smith", 78, 699123456, "john_smith@gmail.es", "Londres", "británico", "jubilado");
    return lista;
  }


  public void guardarPersonas(Persona[] personas) {
    try {
      FileOutputStream ficheroSal = new FileOutputStream("personas.dat");
      ObjectOutputStream fichPersonas = new ObjectOutputStream(ficheroSal);
      for(int i = 0; i < personas.length; ++i) {
        fichPersonas.writeObject(personas[i]);
      }
      fichPersonas.close();
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    }
    System.out.println("Todas las personas han sido guardadas en un fichero.");
  }


  public int[] separarPersonas() {
    int[] longitudes = new int[3];
    try {
      FileInputStream personasEnt = new FileInputStream("personas.dat");
      FileOutputStream menoresSal = new FileOutputStream("menores.dat");
      FileOutputStream adultosSal = new FileOutputStream("adultos.dat");
      FileOutputStream mayoresSal = new FileOutputStream("mayores.dat");
      ObjectInputStream personasObj = new ObjectInputStream(personasEnt);
      ObjectOutputStream fichMenores = new ObjectOutputStream(menoresSal);
      ObjectOutputStream fichAdultos = new ObjectOutputStream(adultosSal);
      ObjectOutputStream fichMayores = new ObjectOutputStream(mayoresSal);
      Persona p = new Persona();
      int men = 0, adu = 0, may = 0;
      for(int i = 0; i < 10; ++i) {
        p = (Persona) personasObj.readObject();
        if(p.Edad() < 18) {
          fichMenores.writeObject(p);
          ++men;
        }
        else if (p.Edad() >= 65) {
          fichMayores.writeObject(p);
          ++may;
        }
        else {
          fichAdultos.writeObject(p);
          ++adu;
        }
      }
      longitudes[0] = men;
      longitudes[1] = adu;
      longitudes[2] = may;
      personasObj.close();
      fichMenores.close();
      fichAdultos.close();
      fichMayores.close();
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    } catch(ClassNotFoundException e) {
      System.err.println("Otros errores de E/S.");
      System.exit(1);
    }
    System.out.println("Las personas han sido separadas según su edad.");
    return longitudes;
  }


  public void muestraPersonas(Persona[] p) {
    for(int i = 0; i < p.length; ++i) {
      System.out.println(p[i].Nombre() + " " + p[i].Apellidos() + " tiene " + p[i].Edad() + " años.");
      System.out.println("Vive en " + p[i].Ciudad() + ", es " + p[i].Nacionalidad() + " de nacimiento.");
      System.out.println("Es " + p[i].Profesion());
      System.out.println("Puede llamarle al " + p[i].Telefono() + " o mandarle un email a " + p[i].Email());
    }
  }


  public Persona[] muestraFichero(String nomFich, int num) {
    Persona[] personas = new Persona[num];
    try {
      FileInputStream ficheroEnt = new FileInputStream(nomFich);
      ObjectInputStream ent = new ObjectInputStream(ficheroEnt);  
      Persona p = new Persona();
      for(int i = 0; i < personas.length; ++i) {
        p = (Persona) ent.readObject();
        personas[i] = p;
      }
      ent.close();
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    } catch(ClassNotFoundException e) {
      System.err.println("Otros errores de E/S.");
      System.exit(1);
    }
    return personas;
  }


  public static void main(String arg[]) {
    UsaPersonaSerializable p = new UsaPersonaSerializable();
    Persona[] personas = p.inicializarListaPersonas();
    p.guardarPersonas(personas);
    int[] longitudes = p.separarPersonas();
    Persona[] menores = p.muestraFichero("menores.dat", longitudes[0]);
    Persona[] adultos = p.muestraFichero("adultos.dat", longitudes[1]);
    Persona[] mayores = p.muestraFichero("mayores.dat", longitudes[2]);
    System.out.println("Los menores de edad son:");
    p.muestraPersonas(menores);
    System.out.println("Los adultos son:");
    p.muestraPersonas(adultos);
    System.out.println("Los mayores de 65 años son:");
    p.muestraPersonas(mayores);
  }
}

