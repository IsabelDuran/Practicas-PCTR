/**
 * Programa en Java que transforma cadenas que almacenen números en números enteros.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;
import java.lang.Integer;

public class CadenasEnteros
{
  public static void main (String[] args)
  {
    String s1 = "2012";
    String s2 = "67.89";
    String s3 = "a213";

    try {
      System.out.print(s1 + " es ");
      int ent1 = new Integer(s1);
      System.out.println(ent1);

      System.out.print(s2 + " es ");
      int ent2 = Integer.parseInt(s2);
      System.out.println(ent2);

      System.out.print(s3 + " es ");
      int ent3 = Integer.valueOf(s3);
      System.out.println(ent3);
    } catch(NumberFormatException e) {
      System.err.println("Error: la cadena no contiene un entero parseable.");
      e.printStackTrace();
      System.exit(-1);
    }
    
  }
}
