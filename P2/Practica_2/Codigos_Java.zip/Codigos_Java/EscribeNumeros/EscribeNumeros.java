/**
 * Programa en Java que escribe en el archivo indicado los 100 primeros números
 * naturales.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class EscribeNumeros {
  public static void main (String[] args) {
    if(args.length != 1) {
      System.err.println("Debe indicar el fichero en el que escribir los números.");
      System.exit(1);
    }
    try {
      FileOutputStream archivoNumeros = new FileOutputStream (args[0]);
      String s;
      for (int i = 0; i < 100; ++i) {
//        s = Integer.valueOf(i).toString();  
//        archivoNumeros.write(Byte.parseByte(s));
        archivoNumeros.write(i);
        archivoNumeros.write(' ');
      }
      archivoNumeros.close();
    } catch(IOException e) {
      System.err.println("Error de escritura: " + e.toString());
      System.exit(1);
    }
  }

}
