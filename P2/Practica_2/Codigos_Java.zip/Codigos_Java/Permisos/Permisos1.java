/**
 * Clase que ilustra el funcionamiento de los modificadores de acceso.
 *
 * @author Natalia Partera
 * @version 1.0
 */

package Permisos;

//import Permisos.Permisos2;

public class Permisos1 {
  public int publico;
  protected int protegido;
  int sinModificador;
  private int privado;
  private Permisos2 perm2;

  public Permisos1(int i) {
    publico = i;
    protegido = i;
    sinModificador = i;
    privado = i;
    perm2 = new Permisos2(i);
  }

  protected Permisos1(int i, int j) {
    publico = i;
    protegido = j;
    sinModificador = i;
    privado = i;
  }

  Permisos1(int i, int j, int k, int l) {
    publico = i;
    protegido = j;
    sinModificador = k;
    privado = l;
  }

  private Permisos1() {}

  public void MetPubl (int i) { /*V*/
    System.out.println("Permisos.Permisos1.MetPubl");
    publico = i;
    System.out.println("Permisos.Permisos1.publico cambiado a " + i);
    protegido = i;
    System.out.println("Permisos.Permisos1.protegido cambiado a " + i);
    sinModificador = i;
    System.out.println("Permisos.Permisos1.sinModificador cambiado a " + i);
    privado = i;
    System.out.println("Permisos.Permisos1.privado cambiado a " + i);
    System.out.println("Llamando a perm2.MetProt(" + i*5 + ")");
    perm2.MetProt(i*5);
    System.out.println("Llamando a Permisos.Permisos1.MetSinM(" + i*4 + ")");
    MetSinM(i*4);
    System.out.println("Fin de Permisos.Permisos1.MetPubl");
  }

  protected void MetProt (int i) {   /**/
    System.out.println("Permisos.Permisos1.MetProt");
    perm2.publico = i;
    System.out.println("perm2.publico cambiado a " + i);
//    perm2.privado = i;
//    System.out.println("Permisos.Permisos2.privado cambiado a " + i);
    MetPriv(i*2);
    System.out.println("Fin de Permisos.Permisos1.MetProt");
  }

  void MetSinM (int i) { /*V*/
    System.out.println("Permisos.Permisos1.MetSinM");
    perm2.protegido = i;
    System.out.println("perm2.protegido cambiado a " + i);
    System.out.println("Llamando a Permisos.Permisos1.MetPriv(" + i+7 + ")");
    MetPriv(i+7);
    perm2.sinModificador = i/2;
    System.out.println("perm2.sinModificador cambiado a " + i/2);
    System.out.println("Fin de Permisos.Permisos1.MetSinM");
  }

  private void MetPriv (int i) {  /*V*/
    System.out.println("Permisos.Permisos1.MetPriv");
    perm2.MetSinM(i-1);
    System.out.println("perm2.MetSinM(" + (i-1) + ")");
    protegido = i;
    System.out.println("Permisos.Permisos1.protegido cambiado a " + i);
//    System.out.println("Llamando a perm2.MetPriv(" + i-8 + ")");
//    perm2.MetPriv(i-8);
    perm2.sinModificador = i;
    System.out.println("perm2.sinModificador cambiado a " + i);
    MetProt(i*10);
    System.out.println("Llamando a Permisos.Permisos1.MetProt(" + i*10 + ")");
    System.out.println("Fin de Permisos.Permisos1.MetPriv");
  }
}
