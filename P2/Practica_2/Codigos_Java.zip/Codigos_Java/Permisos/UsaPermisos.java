/**
 * Programa que ilustra el acceso según la visibilidad de los miembros.
 *
 * @author Natalia Partera
 * @version 1.0
 */

public class UsaPermisos {
  public static void main (String[] args) {
    Permisos p1, p2, p3, p4;

    p1 = new Permisos(1);
    System.out.println("p1.publico = " + p1.publico);
    System.out.println("p1.protegido = " + p1.protegido);
    System.out.println("p1.sinModificador = " + p1.sinModificador);
//    System.out.println("p1.privado = " + p1.privado);    //Acceso no permitido
    p2 = new Permisos(1, 2);
    System.out.println("p2.publico = " + p2.publico);
    System.out.println("p2.protegido = " + p2.protegido);
    System.out.println("p2.sinModificador = " + p2.sinModificador);
//    System.out.println("p2.privado = " + p2.privado);    //Acceso no permitido
    p3 = new Permisos(1, 2, 3, 4);		//Acceso no permitido
    System.out.println("p3.publico = " + p3.publico);
    System.out.println("p3.protegido = " + p3.protegido);
    System.out.println("p3.sinModificador = " + p3.sinModificador);
//    System.out.println("p3.privado = " + p3.privado);    //Acceso no permitido
//    p4 = new Permisos();							//Acceso no permitido

    p1.MetPubl(2);
    p2.MetProt(3);
    p3.MetSinM(4);
//    p1.MetPriv(5);		//Acceso no permitido

    System.out.println("p1.publico = " + p1.publico);
    System.out.println("p1.protegido = " + p1.protegido);
    System.out.println("p1.sinModificador = " + p1.sinModificador);
    System.out.println("p2.publico = " + p2.publico);
    System.out.println("p2.protegido = " + p2.protegido);
    System.out.println("p2.sinModificador = " + p2.sinModificador);
    System.out.println("p3.publico = " + p3.publico);
    System.out.println("p3.protegido = " + p3.protegido);
    System.out.println("p3.sinModificador = " + p3.sinModificador);
  }
}
