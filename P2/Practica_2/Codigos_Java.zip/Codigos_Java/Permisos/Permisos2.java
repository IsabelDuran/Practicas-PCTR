/**
 * Clase que ilustra el funcionamiento de los modificadores de acceso.
 *
 * @author Natalia Partera
 * @version 1.0
 */

package Permisos;

public class Permisos2 {
  public int publico;
  protected int protegido;
  int sinModificador;
  private int privado;

  public Permisos2(int i) {
    publico = i;
    protegido = i;
    sinModificador = i;
    privado = i;
  }

  protected Permisos2(int i, int j) {
    publico = i;
    protegido = j;
    sinModificador = i;
    privado = i;
  }

  Permisos2(int i, int j, int k, int l) {
    publico = i;
    protegido = j;
    sinModificador = k;
    privado = l;
  }

  private Permisos2() {}

  public void MetPubl (int i) {
    System.out.println("Permisos.Permisos2.MetPubl");
    System.out.println("Permisos.Permisos2.publico = " + publico);
    System.out.println("Permisos.Permisos2.protegido = " + protegido);
    System.out.println("Permisos.Permisos2.sinModificador = " + sinModificador);
    System.out.println("Permisos.Permisos2.privado = " + privado);
    System.out.println("Llamando a Permisos.Permisos2.MetProt()");
    MetProt(i+13);
    System.out.println("Fin de Permisos.Permisos2.MetPubl");
  }

  protected void MetProt (int i) {
    System.out.println("Permisos.Permisos2.MetProt");
    protegido = i;
    System.out.println("Permisos.Permisos2.protegido cambiado a " + i);
    System.out.println("Llamando a Permisos.Permisos2.MetPriv(" + i/3 + ")");
    MetPriv(i/3);
    System.out.println("Fin de Permisos.Permisos2.MetProt");
  }

  void MetSinM (int i) {
    System.out.println("Permisos.Permisos2.MetSinM");
    sinModificador = i;
    System.out.println("Permisos.Permisos2.sinModificador cambiado a " + i);
    System.out.println("Fin de Permisos.Permisos2.MetSinM");
  }

  private void MetPriv (int i) {
    System.out.println("Permisos.Permisos2.MetPriv");
    privado = i;
    System.out.println("Permisos.Permisos2.privado cambiado a " + i);
    System.out.println("Llamando a Permisos.Permisos2.MetSinM(" + i+6 + ")");
    System.out.println("Fin de Permisos.Permisos2.MetPriv");
  }
}
