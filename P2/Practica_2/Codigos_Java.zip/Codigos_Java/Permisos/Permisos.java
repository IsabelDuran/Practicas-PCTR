/**
 * Clase que ilustra el funcionamiento de los modificadores de acceso.
 *
 * @author Natalia Partera
 * @version 1.0
 */

public class Permisos {
  public int publico;
  protected int protegido;
  int sinModificador;
  private int privado;

  public Permisos(int i) {
    publico = i;
    protegido = i;
    sinModificador = i;
    privado = i;
  }

  protected Permisos(int i, int j) {
    publico = i;
    protegido = j;
    sinModificador = i;
    privado = i;
  }

  Permisos(int i, int j, int k, int l) {
    publico = i;
    protegido = j;
    sinModificador = k;
    privado = l;
  }

  private Permisos() {}

  public void MetPubl (int i) {
    MetProt(i+13);
  }

  protected void MetProt (int i) {
    protegido = i;
    MetPriv(i/3);
  }

  void MetSinM (int i) {
    sinModificador = i;
  }

  private void MetPriv (int i) {
    privado = i;
    MetSinM(i+6);
  }
}
