/**
 * Programa en Java que recibe un archivo y filtra las vocales.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class FiltraVocales {
  static void FiltraV (FileInputStream entrada, FileOutputStream salida) {
    int i, p;
    char c;

    try {
      while ((p = entrada.read()) >= 0) {
        c = Character.toLowerCase((char) p);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
          salida.write(p);
      }
      entrada.close();
      salida.close();
    } catch (IOException e) {
      System.err.println("Problemas de E/S");
      System.err.println(e.getMessage());
      System.exit(1);
    }  
  }

  public static void main (String[] args) {
    if(args.length != 2) {
      System.err.println("Debe incluir dos nombres de fichero de argumento");
      System.exit(1);
    }
    try {
      FileInputStream entra = new FileInputStream (args[0]);
      FileOutputStream sale = new FileOutputStream (args[1]);
      FiltraV(entra, sale);
    } catch(FileNotFoundException e) {
      System.err.println("Fichero no encontrado...");
      System.err.println(e.getMessage());
      System.exit(1);
    }
  }
}
