/**
 * Programa en Java que saluda por la pantalla.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;


public class Hola_pais
{
  public static void main (String[] args)
  {
    System.out.print("¿En qué país se encuentra? ");
    try {
      InputStreamReader isr = new InputStreamReader(System.in);
      BufferedReader br = new BufferedReader (isr);
      String pais = br.readLine();

      System.out.println("Hola " + pais);
    } catch(IOException exc) {
      System.err.println("¡Ups! Ha tenido lugar un error de E/S");
      exc.printStackTrace();
      System.exit(-1);
    }
    
  }
}
