/**
 * Clase que modela una asignatura.
 *
 * @author Natalia Partera
 * @version 1.0
 */

public class Asignatura
{
  //Atributos privados
  private int codigo;
  private String nombreAsig;
  private String departamento;
  private float creditosAsig;
  private String tipoAsig;
  private int curso;
  private int cuatrimestre;

  //Constructor nulo
  public Asignatura() {}

  //Constructor
  public Asignatura(int cod, String nombre, String dpto, float cred, String tipo, int curs, int cuatr) {
    codigo = cod;
    nombreAsig = nombre;
    departamento = dpto;
    creditosAsig = cred;
    tipoAsig = tipo;
    curso = curs;
    cuatrimestre = cuatr;
  }

  //Métodos observadores
  public int Codigo() {
    return codigo;
  }

  public String NombreAsignatura() {
    return nombreAsig;
  }

  public String Departamento() {
    return departamento;
  }

  public float CreditosAsignatura() {
    return creditosAsig;
  }

  public String TipoAsignatura() {
    return tipoAsig;
  }

  public int Curso() {
    return curso;
  }

  public int Cuatrimestre() {
    return cuatrimestre;
  }

  //Métodos modificadores
  public void CambiarDepartamento(String dpto) {
    departamento = dpto;
  }

  public void CambiarCreditos(float cred) {
    creditosAsig = cred;
  }

  public void CambiarTipo(String tipo) {
    tipoAsig = tipo;
  }

  public void CambiarCurso(int curs) {
    curso = curs;
  }

  public void CambiarCuatrimestre(int cuatr) {
    cuatrimestre = cuatr;
  }

}
