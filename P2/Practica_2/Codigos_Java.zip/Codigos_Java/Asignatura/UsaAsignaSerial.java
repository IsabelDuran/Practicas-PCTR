/**
 * Programa que utiliza la clase AsignaSerial.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;
import java.util.*;

public class UsaAsignaSerial
{
  static void MuestraAsignaturas (AsignaSerial [] asignaturas)
  {
    int i;
    System.out.println("Asignaturas");
    for(i = 0; i < asignaturas.length; ++i) {
      System.out.println("Asignatura: " + asignaturas[i].NombreAsignatura());
      System.out.println("Código: " + asignaturas[i].Codigo());
      System.out.println("Departamento: " + asignaturas[i].Departamento());
      System.out.println("Tipo de asignatura: " + asignaturas[i].TipoAsignatura());
      System.out.println("Nº de créditos: " + asignaturas[i].CreditosAsignatura());
      System.out.println("Curso: " + asignaturas[i].Curso());
      System.out.println("Cuatrimestre: " + asignaturas[i].Cuatrimestre());
      System.out.println();
    }
  }

  public static void main (String[] args)
  {
    AsignaSerial [] segundo = new AsignaSerial[3];

    segundo[0] = new AsignaSerial(21714019, "Arquitectura de Computadores", 
        "Ingeniería de Sistemas y Automática, Tecnología Electrónica", 6, 
        "Obligatoria", 2, 1);
    segundo[1] = new AsignaSerial(21714020, "Programación Concurrente y de Tiempo Real",
        "Lenguajes y Sistemas Informáticos", 6, "Obligatoria", 2, 1);
    segundo[2] = new AsignaSerial(21714017, "Programación Orientada a Objetos", 
        "Lenguajes y Sistemas Informáticos", 6, "Obligatoria", 2, 2);

    try {
      FileOutputStream ficheroSal = new FileOutputStream("datos.dat");
      ObjectOutputStream sal = new ObjectOutputStream(ficheroSal);
      for(int i = 0; i < 3; ++i) {
        sal.writeObject(segundo[i]);
      }
      sal.close();
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    }
    System.out.println("Las asignaturas han sido guardadas correctamente.");
    System.out.println("Ahora las recuperamos.");
    try {
      FileInputStream ficheroEnt = new FileInputStream("datos.dat");
      ObjectInputStream ent = new ObjectInputStream(ficheroEnt);
      AsignaSerial [] recuperadas = new AsignaSerial[3];
      for(int i = 0; i < 3; ++i) {
        recuperadas[i] = (AsignaSerial) ent.readObject();
      }
      System.out.println("Las asignaturas recuperadas son:");
      MuestraAsignaturas(recuperadas);
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    } catch(ClassNotFoundException e) {
      System.err.println("Otros errores de E/S.");
      System.exit(1);
    }
  }
}
