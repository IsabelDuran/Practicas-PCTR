/**
 * Programa que utiliza la clase Asignatura.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class UsaAsignatura2
{
  static void MuestraAsignaturas (Asignatura [] asignaturas)
  {
    int i;
    System.out.println("Asignaturas");
    for(i = 0; i < asignaturas.length; ++i) {
      System.out.println("Asignatura: " + asignaturas[i].NombreAsignatura());
      System.out.println("Código: " + asignaturas[i].Codigo());
      System.out.println("Departamento: " + asignaturas[i].Departamento());
      System.out.println("Tipo de asignatura: " + asignaturas[i].TipoAsignatura());
      System.out.println("Nº de créditos: " + asignaturas[i].CreditosAsignatura());
      System.out.println("Curso: " + asignaturas[i].Curso());
      System.out.println("Cuatrimestre: " + asignaturas[i].Cuatrimestre());
      System.out.println();
    }
  }

  public static void main (String[] args)
  {
    Asignatura [] segundo = new Asignatura[3];

    segundo[0] = new Asignatura(21714019, "Arquitectura de Computadores", 
        "Ingeniería de Sistemas y Automática, Tecnología Electrónica", 6, 
        "Obligatoria", 2, 1);
    segundo[1] = new Asignatura(21714020, "Programación Concurrente y de Tiempo Real",
        "Lenguajes y Sistemas Informáticos", 6, "Obligatoria", 2, 1);
    segundo[2] = new Asignatura(21714017, "Programación Orientada a Objetos", 
        "Lenguajes y Sistemas Informáticos", 6, "Obligatoria", 2, 2);

    MuestraAsignaturas(segundo);
  }
}
