/**
 * Programa que utiliza la clase Asig.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class UsaAsig {

  public static void main (String[] args)
  {
    Asig asig1 = new Asig(21714020, "Programación Concurrente y de Tiempo Real");
    Asig asig2 = new Asig(21714017, "Programación Orientada a Objetos");

    try {
      FileOutputStream ficheroSal = new FileOutputStream("datos.dat");
      ObjectOutputStream sal = new ObjectOutputStream(ficheroSal);
      sal.writeObject(asig1);
      sal.writeObject(asig2);
      sal.close();
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    }
    System.out.println("Dos asignaturas han sido guardadas correctamente.");
    System.out.println("Ahora las recuperamos.");
    try {
      FileInputStream ficheroEnt = new FileInputStream("datos.dat");
      ObjectInputStream ent = new ObjectInputStream(ficheroEnt);
      Asig asig3 = (Asig) ent.readObject();
      Asig asig4 = (Asig) ent.readObject();
      System.out.println("Las asignaturas recuperadas son:");
      System.out.println(asig3.Codigo() + " - " + asig3.Nombre());
      System.out.println(asig4.Codigo() + " - " + asig4.Nombre());
    } catch(FileNotFoundException e) {
      System.err.println("Error de creación de fichero...");
      System.exit(1);
    } catch(IOException e) {
      System.err.println("Error de E/S.");
      System.exit(1);
    } catch(ClassNotFoundException e) {
      System.err.println("Otros errores de E/S.");
      System.exit(1);
    }
  }
}
