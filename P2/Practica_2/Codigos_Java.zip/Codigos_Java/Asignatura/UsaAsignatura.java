/**
 * Programa que utiliza la clase Asignatura.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class UsaAsignatura
{
  public static void main (String[] args)
  {
    Scanner teclado = new Scanner(System.in);
    Asignatura pctr, poo;

    pctr = new Asignatura(21714020, "Programación Concurrente y de Tiempo Real",
        "Lenguajes y Sistemas Informáticos", 6, "Obligatoria", 2, 1);
    poo = new Asignatura(21714017, "Programación Orientada a Objetos", "Lenguajes y "
        + "Sistemas Informáticos", 6, "Obligatoria", 2, 2);

    System.out.println("Asignatura: " + pctr.NombreAsignatura());
    System.out.println("Código: " + pctr.Codigo());
    System.out.println("Departamento: " + pctr.Departamento());
    System.out.println("Tipo de asignatura: " + pctr.TipoAsignatura());
    System.out.println("Nº de créditos: " + pctr.CreditosAsignatura());
    System.out.println("Curso: " + pctr.Curso());
    System.out.println("Cuatrimestre: " + pctr.Cuatrimestre());
    System.out.println();
    System.out.println("Asignatura: " + poo.NombreAsignatura());
    System.out.println("Código: " + poo.Codigo());
    System.out.println("Departamento: " + poo.Departamento());
    System.out.println("Tipo de asignatura: " + poo.TipoAsignatura());
    System.out.println("Nº de créditos: " + poo.CreditosAsignatura());
    System.out.println("Curso: " + poo.Curso());
    System.out.println("Cuatrimestre: " + poo.Cuatrimestre());
    System.out.println();
    System.out.println("Cambiamos la planificación de la titulación.");
    pctr.CambiarCurso(3);
    System.out.println();
    System.out.println("Nueva planificación:");
    System.out.println("Asignatura: " + pctr.NombreAsignatura());
    System.out.println("Código: " + pctr.Codigo());
    System.out.println("Departamento: " + pctr.Departamento());
    System.out.println("Tipo de asignatura: " + pctr.TipoAsignatura());
    System.out.println("Nº de créditos: " + pctr.CreditosAsignatura());
    System.out.println("Curso: " + pctr.Curso());
    System.out.println("Cuatrimestre: " + pctr.Cuatrimestre());
    System.out.println();
    System.out.println("Asignatura: " + poo.NombreAsignatura());
    System.out.println("Código: " + poo.Codigo());
    System.out.println("Departamento: " + poo.Departamento());
    System.out.println("Tipo de asignatura: " + poo.TipoAsignatura());
    System.out.println("Nº de créditos: " + poo.CreditosAsignatura());
    System.out.println("Curso: " + poo.Curso());
    System.out.println("Cuatrimestre: " + poo.Cuatrimestre());
  }
}
