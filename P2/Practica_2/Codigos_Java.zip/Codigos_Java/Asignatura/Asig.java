/**
 * Clase que modela escuetamente una asignatura.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class Asig implements Serializable {
  private int codigo;
  private String nombre;

  public Asig() {}

  public Asig(int cod, String nom) {
    codigo = cod;
    nombre = nom;
  }

  public int Codigo() {
    return codigo;
  }

  public void Codigo(int cod) {
    codigo = cod;
  }

  public String Nombre() {
    return nombre;
  }

  public void Nombre(String nom) {
    nombre = nom;
  }
}
