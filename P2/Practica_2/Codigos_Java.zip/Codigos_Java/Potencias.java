/**
 * Programa en Java que almacena potencias de dos en un array y calcula su suma.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.util.*;

public class Potencias {
  public int[] ArrayPotencias(int num) {
    int[] pot = new int[num];
    int p = 1;
    for(int i = 0; i < num; ++i) {
      pot[i] = p;
      p = p * 2;
    }
    return pot;
  }

  public int SumaArray(int[] array) {
    int suma = 0;
    for(int i = 0; i < array.length; ++i) {
      suma = suma + array[i];
    }
    return suma;
  }

  public static void main (String[] args) {
    if(args.length != 1) {
      System.err.println("Sintaxis incorrecta.");
      System.err.println("Sintaxis: java Potencias entero");
      System.exit(-1);
    }
    int num = Integer.valueOf(args[0]).intValue();
    if(num < 0) {
      System.err.println("Sintaxis incorrecta.");
      System.err.println("El argumento debe ser mayor o igual que 0.");
      System.exit(-1);
    }
    Potencias pot = new Potencias();

    int[] potencias = pot.ArrayPotencias(num);

    int suma = pot.SumaArray(potencias);
    System.out.println("La suma de las " + num + " primeras potencias de 2 es " + suma + ".");
  }
}
