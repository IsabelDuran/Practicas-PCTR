/**
 * Programa que pone en mayúsculas la primera letra de cada palabra de un archivo dado.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;

public class CapitalizarInicio {

  public static void main(String arg[]) {
    char c, ant = '0';
    boolean finArchivo = false;
    long pointer;
    RandomAccessFile archivoLect = null;
    RandomAccessFile archivoEscr = null;

    try {
      archivoLect = new RandomAccessFile("origen.txt", "r");
      archivoEscr = new RandomAccessFile("texto.txt", "rw");
      System.out.println("Los archivos han sido abiertos con éxito.");
      c = (char) archivoLect.readByte();
      do {
        try {          
          if(Character.isLetter(c) && ((archivoLect.getFilePointer() - 1) == 0 || ant == ' '))
            archivoEscr.writeByte(Character.toUpperCase(c));
          else
            archivoEscr.writeByte(c);
          ant = c;
          c = (char) archivoLect.readByte();
        } catch (EOFException e) {
          finArchivo = true;
          archivoLect.close();
          archivoEscr.close();
          System.out.println("Fin de procesamiento de los archivos.");
        }
      } while (!finArchivo);
    } catch (FileNotFoundException e) {
      System.out.println("No se encontró el archivo.");
    } catch (IOException e) {
      System.out.println("Problemas con el archivo.");
    }
  }
}
