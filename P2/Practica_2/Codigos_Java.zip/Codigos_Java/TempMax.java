/**
 * Programa que guarda las temperaturas máximas de los últimos 7 días.
 *
 * @author Natalia Partera
 * @version 2.0
 */

import java.util.*;

public class TempMax
{
  static void MuestraTemperaturas (double [] temperaturas, String [] dias)
  {
    int i;
    System.out.println("Temperaturas");
    for(i = 0; i < temperaturas.length; ++i) {
      System.out.println("El " + dias[i] + " hizo " + temperaturas[i] + " grados de máxima.");
    }
  }

  public static void main (String[] args)
  {
    double [] tMaximas = new double[7];
    String [] dias = new String[7];

    tMaximas[0] = 22.5;
    tMaximas[1] = 21.0;
    tMaximas[2] = 19.5;
    tMaximas[3] = 20.0;
    tMaximas[4] = 22.0;
    tMaximas[5] = 21.5;
    tMaximas[6] = 21.0;

    dias[0] = "martes 6 de marzo de 2012";
    dias[1] = "miércoles 7 de marzo de 2012";
    dias[2] = "jueves 8 de marzo de 2012";
    dias[3] = "viernes 9 de marzo de 2012";
    dias[4] = "sábado 10 de marzo de 2012";
    dias[5] = "domingo 11 de marzo de 2012";
    dias[6] = "lunes 12 de marzo de 2012";

    MuestraTemperaturas(tMaximas, dias);
  }
}
