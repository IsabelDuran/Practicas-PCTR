/**
 * Programa que muestra el contenido del directorio.
 *
 * @author Natalia Partera
 * @version 1.0
 */

import java.io.*;
import java.util.*;


public class ListarDirectorio {
  public static void main (String arg[]) {
    String directorio;
    if(arg.length > 0)
      directorio = arg[0];
    else
      directorio = ".";

    File actual = new File(directorio);
    System.out.print("El directorio es: ");
    try {
      System.out.println(actual.getCanonicalPath());
    } catch (IOException e) {
      System.err.println("¡Error! El programa finalizará.");
      System.exit(-1);
    }
    System.out.println("Su contenido es:");

    String[] archivos = actual.list();
    for(int i = 0; i < archivos.length; ++i)
      System.out.println(archivos[i]);
  }
}
