  /**
   * Clase Objeto.
   * [Ejercicio]
   * @author Natalia Partera
   * @version 1.0
   */

  public class Objeto {
    
    private String nombre;

    //Constructor de la clase
    public Objeto(String obj) {
      nombre = obj;
    }

    //Método observador que devuelve el nombre del objeto
    public String Nombre() {
      return nombre;
    }

  }
