  /**
   * Clase Impresora.
   * [Ejercicio]
   * @author Natalia Partera
   * @version 1.0
   */

  public class Impresora {
    //Constructores
    public Impresora() {}

    //Métodos
    public void imprimir() {
      for(int i = 0; i < 100000; ++i) {}
    }
  }
